var App = angular.module("App", []);

App.controller("FirstCtrl", function($scope){
    $scope.data = {
      message : "Hello"
    };
});